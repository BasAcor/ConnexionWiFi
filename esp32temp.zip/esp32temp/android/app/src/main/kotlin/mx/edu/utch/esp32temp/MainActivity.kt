package mx.edu.utch.esp32temp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
