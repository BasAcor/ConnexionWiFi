import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
class Api {
  static Future<String> getSensor(String sensor) async{
    //Navegador web
    http.Client cliente = http.Client();
    //url del sitio
    Uri url = Uri.parse("http://192.168.2.27/$sensor");
    //consumir con un GET la api
    http.Response respuesta = await http.get(url);
    if (respuesta.statusCode == 200) {
      return respuesta.body;
    }else{
      return "Error de sensor";
    }
  }
}