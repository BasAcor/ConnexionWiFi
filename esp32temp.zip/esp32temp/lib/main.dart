import 'package:esp32temp/pantallas/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(App());
}
